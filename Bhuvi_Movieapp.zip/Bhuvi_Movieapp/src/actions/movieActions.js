
import * as types from './actionTypes';
import axios from 'axios';

//to return result with action type
export function loadedMovies(movies) {	 
  return { type: types.LOADED_MOVIES, movies};
}

// to fetch default movie
export function loadMovies() {	
	return dispatch => {
	    return (axios.get(`http://www.omdbapi.com/?i=tt3896198&apikey=fa281222`)
        .then(response => {
	      dispatch(loadedMovies(response.data));
	    }).catch(error => {
	      throw(error);
	    })
	    
	  )};

}

//to fetch movie list based on user search
export function searchMovies(movie) {
	 return dispatch => {
		    return (axios.get(`http://www.omdbapi.com/?i=tt3896198&apikey=fa281222&s=${movie}&page=1`)
	        .then(response => {
	        	if(response && response.data.Search)
		      dispatch(loadedMovies(response.data.Search.slice(0, 5)));
	        	else{
	        		dispatch(loadedMovies("Too Many Results"));
	        	}
		    }).catch(error => {
		            throw(error);
		    })
		    
		  )};
	

	
}
