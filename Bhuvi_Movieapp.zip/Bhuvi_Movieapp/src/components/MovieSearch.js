import React, { Component } from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import MovieList from './MoviesList';
import '../css/search.css';
import * as movieActions from '../actions/movieActions';

class MovieSearch extends Component {
	constructor(props) {
	    super(props);
	this.onSearchMovie = this.onSearchMovie.bind(this);
}

	onSearchMovie(event) {
		let movie = event.target.value;
		this.props.searchmovies(movie);
	}
      
	
	render() {
    	if(this.props.movie === 'Too Many Results' ){
    		return (
    		        <div>		     
    		        	<div className="search">
    		                <input type="search" name="movie-search"  onChange={this.onSearchMovie} />
    		            <div className="center">
    		               Too Many Results... 
    		               </div>
    		           </div>
    		           </div>
    		        );
    	}
    	else if(this.props.movie.length > 0){
    		return (
    		        <div>
    		        	<div className="search">
    		                <input type="search" name="movie-search"  onChange={this.onSearchMovie} />
    		            </div>
    		                <table className='table table-striped table-condensed'>   
    		                <tbody>
    		                 {this.props.movie.map(m => 
    		                	<tr> 
    		               <td>
    		                 <MovieList movie={m} />  
    		                 		</td>
    		                </tr>
    		                  )}
    		                </tbody>
    		              </table>
    		           </div>
    		        );	
    	}else{
        return (
        <div>
        	<div className="search">
                <input type="search" name="movie-search"  onChange={this.onSearchMovie} />
            </div>
                <MovieList movie={this.props.movie} />
           </div>
        );
    	}
    }
}


function mapStateToProps(state, ownProps) {
  return {
    results: state.searchmovies
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(movieActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(MovieSearch);


