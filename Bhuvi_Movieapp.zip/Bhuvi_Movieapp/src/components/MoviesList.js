import React from 'react';
import '../css/movie-list.css';

export default class MoviesList extends React.Component {

render() {
    return (
    		<div>
    		<div className="movie-header" style={{ backgroundImage: `url(${ this.props.movie.Poster})` }}>
</div>
                <div className="movie-content">
                    <div className="movie-content-header">
                        <h3 className="movie-title">{ this.props.movie.Title}</h3>
                    </div>
                    <div className="movie-info">
                        <div className="info-section">
                            <label>Released</label>
                            <span>{ this.props.movie.Released}</span>
                        </div>
                        <div className="info-section">
                            <label>IMDB Rating</label>
                            <span>{ this.props.movie.imdbRating}</span>
                        </div>
                        <div className="info-section">
                            <label>Rated</label>
                            <span>{ this.props.movie.Rated}</span>
                        </div>
                        <div className="info-section">
                            <label>Runtime</label>
                            <span>{ this.props.movie.Runtime}</span>
                        </div>
                    </div>
                    <div className="plot" style={{fontSize: '12px'}}>
                        <p>{ this.props.movie.Plot}</p>
                    </div>
                </div>
</div>


    );
  }

}

