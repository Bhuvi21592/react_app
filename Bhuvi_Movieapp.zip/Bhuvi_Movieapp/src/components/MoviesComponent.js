import React, {Component} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import toastr from 'toastr';
import * as movieActions from '../actions/movieActions';
import MovieSearch from './MovieSearch';


class MoviesComponent extends Component {
  constructor(props) {
    super(props);
    toastr.options.timeOut = 1000;
    this.searchMovie = this.searchMovie.bind(this);
  
  }
  // to initiate the movie search based on user request
  searchMovie(movie) {
    this.props.actions.searchMovies(movie);
  }
  
  render() {
    return (
    		<div className="container">
    		
            <div className="movie-card">
            <div > 
            
            <div className="right"> 
            <label>Hello Bhuvaneswari </label>
           
            </div>
            <div className="left"> 
            <b> Movie Catalog : </b>
            </div>
           </div>
            	<MovieSearch movie={this.props.movie} searchmovies={this.searchMovie} />
            
            	</div>
        </div>


    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    movie: state.movies
}
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(movieActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(MoviesComponent);

